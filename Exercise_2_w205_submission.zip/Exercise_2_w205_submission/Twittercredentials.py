import tweepy

consumer_key = "DvViHgpo3TIBT5mOVdO1Xs8j1";
#eg: consumer_key = "YisfFjiodKtojtUvW4MSEcPm";


consumer_secret = "ZItTWDVCTUGR2NaRVWoyMq8cwfTMxCUnYl7YrEQRI9WU7Rhl7U";
#eg: consumer_secret = "YisfFjiodKtojtUvW4MSEcPmYisfFjiodKtojtUvW4MSEcPmYisfFjiodKtojtUvW4MSEcPm";

access_token = "845805047267045376-B4lHKhNVqUrxCbxXiXrkafQGRWpZYjI";
#eg: access_token = "YisfFjiodKtojtUvW4MSEcPmYisfFjiodKtojtUvW4MSEcPmYisfFjiodKtojtUvW4MSEcPm";

access_token_secret = "rzei13xd17RS88mFL8EM972gT2JmIpJOPj5w2A8UWVCx4";
#eg: access_token_secret = "YisfFjiodKtojtUvW4MSEcPmYisfFjiodKtojtUvW4MSEcPmYisfFjiodKtojtUvW4MSEcPm";


auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)

api = tweepy.API(auth)



