Exercise 2 Submission. 

You'll find a screenshots pdf file in this folder which I communicated to you earlier.

It contains all the screenshots required as well as more-I have tried to capture screenshots for every key step along the way of this project exercise.

Instead of using a seprate .png file, I have included the top twenty words histogram also in this file.

A documentation on the general architecture and methdology is also included in the other pdf file "Twitter_Application_Documentation_KMaitra_Ex2_W205".

Rest of the folder structure is consistent with general instructions of the project-

1. The key folder is extweetwordcount (referred to as just tweetwordcount in Figure 2 in the Twitter_Application_Documentation_KMaitra_Ex2_W205.pdf file
2. The sub-directory structure is also pretty conventional, with the topologies sub-folder containing the .clj file

